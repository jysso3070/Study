데이터베이스 이름	2019GameServer_2015184024
ODBC 이름   2015184024_gameserver

테이블에 있는 아이디 목록
jys
jnh
kpu1
kpu2
kpu3
kpu4
kpu5
kpu6
kpu7
kpu8