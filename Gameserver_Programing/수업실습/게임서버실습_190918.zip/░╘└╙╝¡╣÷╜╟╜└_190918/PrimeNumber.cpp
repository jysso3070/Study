//#include <stdio.h>
//#include <tchar.h>
#include <vector>
#include <iostream>
#include <chrono>
#include <thread>
#include <mutex>
#include <atomic>

using namespace std;
using namespace chrono;
const int MAX_NUM = 450000;
vector<int> g_primes;
mutex g_pl;
atomic<int> g_count = 0;
mutex g_cl;

bool IsPrimeNumber(int number)
{
	if (number == 1)
		return false;
	if (number == 2)
		return true;
	if (0 == (number % 2))
		return false;
	for (int i = 3; i < number - 1; i += 2)
	{
		if ((number % i) == 0)
			return false;
	}
	return true;
}

void PrintNumbers(const vector<int>& primes)
{
	for (int v : primes)
	{
		cout << v << endl;
	}
}

void thread_func()
{
	while (true)
	{
		int num;
		{
			if (g_count > MAX_NUM) break;
			//lock_guard < mutex> ll(g_cl);		// g_count�� ��������� �����ϸ� ���� �����ʾƵ� �ȴ�.
			num = g_count++;

			//this_thread::sleep_for(1ms);
			// ++g_count; 

		}

		if (IsPrimeNumber(num) == true)
		{
			g_pl.lock();
			g_primes.push_back(num);
			g_pl.unlock();
		}

	}
}

int main()
{
	vector<thread> threads;
	auto start_t = system_clock::now();
	for (int i = 0; i < 4; ++i)
	{
		threads.emplace_back(thread_func);
	}
	for (auto &th : threads) th.join();		// �� �����尡 ���������� ��ٸ�

	auto end_t = system_clock::now();
	auto exec_t = end_t - start_t;
	auto exec_ms = duration_cast<milliseconds>(exec_t).count();

	cout << " Number of Prime less than " << MAX_NUM << " is " << g_primes.size() << endl;
	cout << "Execution Time is " << exec_ms << "milliseconds. " << endl;
	system("pause");
	return 0;
}
