다수의 클라이언트로부터 수신하여 다시 그대로 회신하는 즉 echo를 하는 서버입니다.

이것을 실행한 후 tcp_many_client를 실행하십시오.

# 리눅스에서 빌드하기

Visual Studio 2019이나 최신 버전에서 본 프로젝트를 열고 빌드하십시오.
가령 https://devblogs.microsoft.com/cppblog/targeting-windows-subsystem-for-linux-from-visual-studio/ 를 참고하십시오.

