#pragma once
#include <thread>
#include <vector>
#include <queue>

#include "ServerManager.h"


using namespace std;
using namespace chrono;

constexpr int START_POSITION = 4;

struct TIMER_EVENT
{
	int object_id;
	EVENT_TYPE event_type;
	std::chrono::high_resolution_clock::time_point start_time;

	constexpr bool operator< (const TIMER_EVENT& _lhs) const {
		return start_time > _lhs.start_time;
	}
};

ServerManager gServer;
priority_queue<TIMER_EVENT> timer_queue;

std::uniform_int_distribution<> uid;
std::default_random_engine dre;

void ProcessEvent(TIMER_EVENT ev);
void WakeUpNpc(NPCINFO& npc);

void CheckPlayerID(int id, int user_id)
{
	int idList[5] = { 1,2,3,4,5 };
	for (int user : idList) {
		if (user == user_id) {
			gServer.send_login_packet(id, SC_LOGIN_OK);
			gServer.LoadPlayer(id, START_POSITION, START_POSITION);
			for (auto&& r : gServer.clients[id].npc_al) {
				WakeUpNpc(gServer.npcs[r]);
			}
			return;
		}
	}
	gServer.send_login_packet(id, SC_LOGIN_FAIL);
}

void process_packet(int id, char *packet)
{
	if (packet[1] == CS_LOGIN_REQUEST) {
		cs_login_request_packet *p = reinterpret_cast<cs_login_request_packet *>(packet);
		CheckPlayerID(id, p->user_id);
	}
	else {	//CS_MOVE
		gServer.CSMovePacket_Process(id, packet);
		for (auto&& r : gServer.clients[id].npc_al) {
			WakeUpNpc(gServer.npcs[r]);
		}
	}
}

void do_work()
{
	while (true) {
		DWORD io_byte;
		ULONG_PTR l_key;
		OVER_EX * over;
		bool error = GetQueuedCompletionStatus(gServer.g_iocp, &io_byte,
			&l_key, reinterpret_cast<LPWSAOVERLAPPED *>(&over), INFINITE);
		int key = static_cast<int>(l_key);

		if (!error) {
			gServer.error_message("GQCS");
		}
		if (io_byte == 0) {
			gServer.disconnect(key);
			gServer.error_message("Io_byte Zero");
			continue;
		}
		switch (over->event_type) {
		case EV_RECV:
		{
			SOCKINFO& client = gServer.clients[key];
			int rest_size = io_byte;
			char *ptr = over->messageBuf;
			char packet_size{ 0 };

			if (0 < client.prevBufferSize)
				packet_size = client.packetBuf[0];

			while (0 < rest_size) {
				if (packet_size == 0)
					packet_size = ptr[0];
				int required = packet_size - client.prevBufferSize;
				if (rest_size >= required) {
					memcpy(client. packetBuf + client.prevBufferSize, ptr, required);
					process_packet(key, client.packetBuf);
					rest_size -= required;
					ptr += required;
					packet_size = 0;
				}
				else {
					memcpy(client.packetBuf + client.prevBufferSize, ptr, rest_size);
					rest_size = 0;
				}
			}
			gServer.do_recv(key);
			break;
		}
		case EV_SEND:
		{
			delete over;
			break;
		}
		case EV_NPC_WANDER:
		{
			TIMER_EVENT ev;
			ev.object_id = key;
			ev.event_type = over->event_type;
			ev.start_time = high_resolution_clock::now();
			ProcessEvent(ev);
			break;
		}
		default:
			break;
		}
	}
}

void do_timer()
{
	while (true) {
		this_thread::sleep_for(10ms);

		while (!timer_queue.empty()) {
			TIMER_EVENT ev = timer_queue.top();
			if (high_resolution_clock::now() < ev.start_time) break;
			timer_queue.pop();
			OVER_EX *over = new OVER_EX;
			over->event_type = ev.event_type;
			PostQueuedCompletionStatus(gServer.g_iocp, 1, ev.object_id, &over->overlapped);
		}
	}
}

void do_accept()
{
	gServer.Accept();
}

int main()
{
	vector<thread> th;
	wcout.imbue(locale("korean"));
	gServer.InitializeServer();

	for (int i = 0; i < 4; ++i)
		th.emplace_back(thread{ do_work });
	th.emplace_back(thread{ do_accept });
	th.emplace_back(thread{ do_timer });

	for (auto&& t : th)
		t.join();
}


void AddTimer(int target, EVENT_TYPE ev, high_resolution_clock::time_point start_time)
{
	timer_queue.push(TIMER_EVENT{ target, ev, start_time });
}

void WakeUpNpc(NPCINFO& npc)
{
	if (npc.sleeping) {
		npc.sleeping = false;
		AddTimer(npc.id, EV_NPC_WANDER, high_resolution_clock::now() + 1s);
	}
}

void Npc_Wander(int id)	// �ΰ������� ��ũ��Ʈ ��������.
{
	NPCINFO& npc = gServer.npcs[id];

	unordered_set<int> new_vl;
	unordered_set<int> old_vl;

	for (int i = 0; i < MAX_USER; ++i) {
		if (!gServer.clients[i].active) continue;
		if (!gServer.clients[i].Is_Near_Object(npc)) continue;
		old_vl.insert(i);
	}
	
	switch (uid(dre) % 4) {
	case 0: if (npc.x < MAP_SCALE - 1) ++npc.x; break;
	case 1: if (npc.x > 0) --npc.x; break;
	case 2: if (npc.y < MAP_SCALE - 1) ++npc.y; break;
	case 3: if (npc.y > 0) --npc.y; break;
	default: break;
	}

	for (int i = 0; i < MAX_USER; ++i) {
		if (!gServer.clients[i].active) continue;
		if (!gServer.clients[i].Is_Near_Object(npc)) continue;
		new_vl.insert(i);
	}

	for (auto&& r : new_vl) {
		if(old_vl.count(r))
			gServer.send_move_player_packet(gServer.clients[r], npc);
		else {
			gServer.send_put_player_packet(gServer.clients[r], npc);
		}
	}

	for (auto&& r : old_vl) {
		if (!new_vl.count(r))
			gServer.send_remove_player_packet(gServer.clients[r], npc);
	}

	for (int i = 0; i < MAX_USER; ++i) {
		if (!gServer.clients[i].Is_Awakable_Npc(npc) && gServer.clients[i].npc_al.count(id))
			gServer.clients[i].npc_al.erase(id);
	}
}

void ProcessEvent(TIMER_EVENT ev)
{
	NPCINFO& npc = gServer.npcs[ev.object_id - MAX_USER];
	
	switch (ev.event_type) {
	case EV_NPC_WANDER:
		Npc_Wander(ev.object_id - MAX_USER);
		break;
	}
	bool sleep = true;

	for (int i = 0; i < MAX_USER; ++i) {
		if (!gServer.clients[i].active) continue;
		if (!npc.Is_Near_Target(gServer.clients[i])) continue;
		sleep = false;
	}

	npc.sleeping = sleep;

	if (!npc.sleeping) {
		AddTimer(npc.id, EV_NPC_WANDER, high_resolution_clock::now() + 1s);
	}
}