#pragma once

constexpr int PORT = 4321;
constexpr int WIN_WIDTH = 520;
constexpr int WIN_HEIGHT = 520;
constexpr int NODE_LENGTH = 25;
constexpr int MAP_SCALE = 100;

constexpr int SC_LOGIN_OK = 1;
constexpr int SC_LOGIN_FAIL = 2;
constexpr int SC_PUT_PLAYER = 3;
constexpr int SC_MOVE_PLAYER = 4;
constexpr int SC_REMOVE_PLAYER = 5;

constexpr int CS_UP = 1;
constexpr int CS_DOWN = 2;
constexpr int CS_LEFT = 3;
constexpr int CS_RIGHT = 4;
constexpr int CS_LOGIN_REQUEST = 5;

constexpr int MAX_BUFFER = 1024;
constexpr int MAX_USER = 10;
constexpr int NUM_NPC = 2000;

struct sc_login_packet
{
	char size;
	char type;
	int id;
};

struct sc_put_player_packet
{
	char size;
	char type;
	int id;
	int x, y;
};

struct sc_remove_player_packet
{
	char size;
	char type;
	int id;
};

struct sc_move_player_packet
{
	char size;
	char type;
	int id;
	int x, y;
};

struct cs_move_packet
{
	char size;
	char type;
};

struct cs_login_request_packet
{
	char size;
	char type;
	int  user_id;
};