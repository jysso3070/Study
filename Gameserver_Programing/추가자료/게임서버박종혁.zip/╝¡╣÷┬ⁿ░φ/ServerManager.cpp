#include "ServerManager.h"

ServerManager::ServerManager()
{
}

ServerManager::~ServerManager()
{
}

void ServerManager::InitializeServer()
{
	g_iocp = CreateIoCompletionPort(INVALID_HANDLE_VALUE, NULL, NULL, NULL);
	InitNpc();
}

void ServerManager::InitNpc() {
	int id = MAX_USER;
	for (int i = 0; i < NUM_NPC; ++i) {
		npcs[i].x = uid(dre) % MAP_SCALE;
		npcs[i].y = uid(dre) % MAP_SCALE;
		npcs[i].sleeping = npcs[i].active = true;
		npcs[i].id = id++;

		npcs[i].L = luaL_newstate();
		luaL_openlibs(npcs[i].L);
		int error = luaL_loadfile(npcs[i].L, "NPC_AI.lua");
		if (error) lua_errorDisplay(npcs[i].L);
		error = lua_pcall(npcs[i].L, 0, 0, 0);
		if (error) lua_errorDisplay(npcs[i].L);

		lua_getglobal(npcs[i].L, "set_ID");
		lua_pushnumber(npcs[i].L, id);
		lua_pcall(npcs[i].L, 1, 0, 0);

		lua_register(npcs[i].L , "API_GetClientPosX", this->API_GetClientPosX);
		lua_register(npcs[i].L , "API_GetClientPosY", this->API_GetClientPosY);
		lua_register(npcs[i].L , "API_GetNpcPosX", API_GetNpcPosX);
		lua_register(npcs[i].L , "API_GetNpcPosY", this->API_GetNpcPosY);
	}
	
}

void ServerManager::lua_errorDisplay(lua_State *L)
{
	std::cout << lua_tostring(L, -1) << std::endl;
	lua_pop(L, 1);
}

void ServerManager::LoadPlayer(int id, int _x, int _y)	//Ŭ�� �����Ͱ� �������� ����ü�� ����.
{
	SOCKINFO& client = clients[id];
	client.x = _x;
	client.y = _y;
	client.active = true;
	client.client_vl = GetNearClientList(id);
	client.npc_al = GetAwakableNpcList(id);
	send_put_player_packet(client, client);
	for (auto&& r : client.client_vl) {
		send_put_player_packet(client, clients[r]);
		send_put_player_packet(clients[r], client);
	}

	for (auto&& r : client.npc_al) {
		if (client.Is_Near_Object(npcs[r]))
			send_put_player_packet(client, npcs[r]);
	}
}

void ServerManager::CSMovePacket_Process(int id, char *packet)
{
	SOCKINFO& client = clients[id];
	cs_move_packet *p = reinterpret_cast<cs_move_packet *>(packet);
	std::unordered_set<int>& old_vl = client.client_vl;
	std::unordered_set<int>& npc_old_al = client.npc_al;
	std::unordered_set<int> npc_old_vl;

	for (auto&& r : npc_old_al) {
		if (client.Is_Near_Object(npcs[r]))
			npc_old_vl.insert(r);
	}

	switch (p->type) {
	case CS_UP:
		if (client.y > 0)
			--client.y;
		break;

	case CS_DOWN:
		if (client.y < WIN_HEIGHT - 1)
			++client.y;
		break;

	case CS_LEFT:
		if (client.x > 0)
			--client.x;
		break;

	case CS_RIGHT:
		if (client.x < WIN_WIDTH - 1)
			++client.x;
		break;
	}

	std::unordered_set<int> new_vl;
	std::unordered_set<int> npc_new_al;

	new_vl = GetNearClientList(id);
	npc_new_al = GetAwakableNpcList(id);

	send_move_player_packet(client, client);

	for (auto&& r : new_vl) {
		if (old_vl.count(r)) {	// new_vl && old_vl
			if (!clients[r].client_vl.count(id)) {
				clients[r].client_vl.insert(client.id);
				send_put_player_packet(clients[r], client);
			}
			else
				send_move_player_packet(clients[r], client);
		}
		else {					//new_vl && !old_vl
			client.client_vl.insert(r);
			send_put_player_packet(client, clients[r]);
			if (clients[r].client_vl.count(id))
				send_move_player_packet(clients[r], client);
			else {
				clients[r].client_vl.insert(id);
				send_put_player_packet(clients[r], client);
			}
		}
	}
	for (auto&& r : old_vl) {
		if (new_vl.count(r)) continue;	// new_vl && old_vl
		// !new_vl && old_vl
		client.client_vl.erase(r);
		send_remove_player_packet(client, clients[r]);

		if (clients[r].client_vl.count(id)) {
			clients[r].client_vl.erase(id);
			send_remove_player_packet(clients[r], client);
		}
	}

	for (auto&& r : npc_new_al) {
		if (!npc_old_al.count(r)) 
			client.npc_al.insert(r);
		
		if (client.Is_Near_Object(npcs[r])) {
			if (!npc_old_vl.count(r))
				send_put_player_packet(client, npcs[r]);
		}
		else {
			if (npc_old_vl.count(r))
				send_remove_player_packet(client, npcs[r]);
		}
	}

	for (auto&& r : npc_old_al) {
		if(!npc_new_al.count(r))
			client.npc_al.erase(r);
	}
}

void ServerManager::send_packet(const SOCKINFO& to, void* p)
{
	char * packet = reinterpret_cast<char *>(p);
	OVER_EX * over = new OVER_EX;
	memcpy(over->messageBuf, packet, packet[0]);
	::memset(&over->overlapped, 0, sizeof(WSAOVERLAPPED));
	over->wsaBuf.len = packet[0];
	over->wsaBuf.buf = over->messageBuf;
	over->event_type = EV_SEND;

	int error = WSASend(to.socket, &over->wsaBuf, 1, 0, 0,
		&over->overlapped, NULL);
	if (error) {
		error_message("WSASend");
	}
}

void ServerManager::send_login_packet(int to, int res)
{
	sc_login_packet packet;
	packet.size = sizeof(packet);
	packet.type = res;
	packet.id = to;

	send_packet(clients[to], &packet);
}

void ServerManager::send_put_player_packet(const SOCKINFO& to, const Object& target)
{
	sc_put_player_packet packet;
	packet.size = sizeof(packet);
	packet.type = SC_PUT_PLAYER;
	packet.id = target.id;
	packet.x = target.x;
	packet.y = target.y;

	send_packet(to, &packet);
}

void ServerManager::send_move_player_packet(const SOCKINFO& to, const Object& target)
{
	sc_move_player_packet packet;
	packet.size = sizeof(packet);
	packet.type = SC_MOVE_PLAYER;
	packet.id = target.id;
	packet.x = target.x;
	packet.y = target.y;

	send_packet(to, &packet);
}

void ServerManager::send_remove_player_packet(const SOCKINFO& to, const Object& target)
{
	sc_remove_player_packet packet;
	packet.size = sizeof(packet);
	packet.type = SC_REMOVE_PLAYER;
	packet.id = target.id;

	send_packet(to, &packet);
}

void ServerManager::disconnect(int id)	// ���� ���� �� ��ġ�� �����ص� �� ��.
{
	for (int i = 0; i < MAX_USER; ++i) {
		if (clients[i].active && i != id) {
			send_remove_player_packet(clients[i], clients[id]);
			clients[i].client_vl.erase(id);
		}
	}
	clients[id].id = -1;
	clients[id].active = false;
	closesocket(clients[id].socket);
}

void ServerManager::Accept()
{
	WSADATA wsaData;
	if (WSAStartup(MAKEWORD(2, 0), &wsaData) != 0) {
		error_message("WSAStartup");
		return;
	}

	SOCKET listenSock = WSASocket(AF_INET, SOCK_STREAM, 0, NULL, 0, WSA_FLAG_OVERLAPPED);
	if (listenSock == INVALID_SOCKET) {
		error_message("WSASocket");
		return;
	}

	SOCKADDR_IN serverAddr;
	::memset(&serverAddr, 0, sizeof(serverAddr));
	serverAddr.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(PORT);

	if (::bind(listenSock, (sockaddr *)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
		error_message("Bind");
		closesocket(listenSock);
		WSACleanup();
		return;
	}

	if (listen(listenSock, 5) == SOCKET_ERROR) {
		error_message("Listen");
		closesocket(listenSock);
		WSACleanup();
		return;
	}

	DWORD flags;
	SOCKET clientSock;
	SOCKADDR_IN clientAddr;
	int addrLen = sizeof(clientAddr);
	::memset(&clientAddr, 0, addrLen);

	while (true) {
		clientSock = accept(listenSock, (sockaddr *)&clientAddr, &addrLen);
		if (clientSock == INVALID_SOCKET) {
			error_message("accpet");
			return;
		}

		int new_id = -1;
		for (int i = 0; i < MAX_USER; ++i) {
			if (clients[i].id == -1) {
				new_id = i;
				break;
			}
		}
		if (new_id == -1) {
			error_message("Maximum Clients Limited");
			continue;
		}

		clients[new_id].socket = clientSock;
		clients[new_id].id = new_id;
		::memset(&clients[new_id].over.overlapped, 0, sizeof(WSAOVERLAPPED));
		clients[new_id].prevBufferSize = 0;
		flags = 0;

		CreateIoCompletionPort(reinterpret_cast<HANDLE>(clientSock), g_iocp, new_id, 0);

		clients[new_id].client_vl.clear();
		clients[new_id].npc_al.clear();

		do_recv(new_id);
	}
	closesocket(clientSock);
	closesocket(listenSock);
	WSACleanup();
	return;
}

void ServerManager::do_recv(int id)
{
	DWORD flags = 0;
	OVER_EX& over = clients[id].over;
	over.wsaBuf.buf = over.messageBuf;
	over.wsaBuf.len = MAX_BUFFER;
	over.event_type = EV_RECV;
	::memset(&over.overlapped, 0, sizeof(WSAOVERLAPPED));

	int error = WSARecv(clients[id].socket, &clients[id].over.wsaBuf,
		1, NULL, &flags, &clients[id].over.overlapped, NULL);
	if (error) {
		int errCode = WSAGetLastError();
		if (errCode != WSA_IO_PENDING) {
			error_message("WSARecv");
			while (true);
		}
	}
}



std::unordered_set<int> ServerManager::GetNearClientList(int id)
{
	SOCKINFO& client = clients[id];
	std::unordered_set<int> res;
	for (int i = 0; i < MAX_USER; ++i) {
		if (!clients[i].active || i == id) continue;
		if (!client.Is_Near_Object(clients[i])) continue;
		res.insert(i);
	}
	return res;
}

std::unordered_set<int> ServerManager::GetAwakableNpcList(int id)
{
	SOCKINFO& client = clients[id];
	std::unordered_set<int> res;
	for (int i = 0; i < NUM_NPC; ++i) {
		if (!npcs[i].active) continue;
		if (!client.Is_Awakable_Npc(npcs[i])) continue;
		res.insert(i);
	}
	return res;
}

void ServerManager::error_message(std::string info)
{
	std::cout << "Error - " << info << std::endl;
}

bool SOCKINFO::Is_Near_Object(const Object& other) const {
	if (abs(x - other.x) > CLIENT_VIEW_RADIUS) return false;
	if (abs(y - other.y) > CLIENT_VIEW_RADIUS) return false;
	return true;
}

bool SOCKINFO::Is_Awakable_Npc(const NPCINFO& other) const {
	if (abs(x - other.x) > NPC_VIEW_RADIUS) return false;
	if (abs(y - other.y) > NPC_VIEW_RADIUS) return false;
	return true;
}

bool NPCINFO::Is_Near_Target(const Object & other) const
{
	if (abs(x - other.x) > NPC_VIEW_RADIUS) return false;
	if (abs(y - other.y) > NPC_VIEW_RADIUS) return false;
	return true;
}

int ServerManager::API_GetClientPosX(lua_State *L)
{
	int id = (int)lua_tonumber(L, -1);
	int posX = clients[id].x; 
	lua_pop(L, 2);
	lua_pushnumber(L, posX);
	return 1;
}

int ServerManager::API_GetNpcPosX(lua_State *L)
{
	int id = (int)lua_tonumber(L, -1);
	int posX = npcs[id].x;
	lua_pop(L, 2);
	lua_pushnumber(L, posX);
	return 1;
}

int ServerManager::API_GetClientPosY(lua_State *L)
{
	int id = (int)lua_tonumber(L, -1);
	int posY = clients[id].y;
	lua_pop(L, 2);
	lua_pushnumber(L, posY);
	return 1;
}

int ServerManager::API_GetNpcPosY(lua_State *L)
{
	int id = (int)lua_tonumber(L, -1);
	int posY = npcs[id].y;
	lua_pop(L, 2);
	lua_pushnumber(L, posY);
	return 1;
}

//int API_Send_Message(lua_State *L)
//{
//	int to = (int)lua_tonumber(L, -3);
//	int from = (int)lua_tonumber(L, -2);
//	char *message = (char *)lua_tostring(L, -1);
//	wchar_t wmess[MAX_STR_LEN];
//	size_t wlen;
//
//	mbstowcs_s(&wlen, wmess, strlen(message), message, _TRUNCATE);
//	lua_pop(L, 4);
//	send_chat_packet(to, from, wmess);
//}