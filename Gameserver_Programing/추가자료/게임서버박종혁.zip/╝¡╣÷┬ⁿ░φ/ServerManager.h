#pragma once
#include "protocol.h"
#include <unordered_set>
#include <iostream>
#include <random>
#include <chrono>
#include <string>
#include <mutex>

extern "C" {
#include "include/lua.h"
#include "include/lauxlib.h"
#include "include/lualib.h"
}

#include <WinSock2.h>

#pragma comment(lib, "lua53.lib")
#pragma comment(lib,"ws2_32.lib")

constexpr int CLIENT_VIEW_RADIUS = 7;
constexpr int NPC_VIEW_RADIUS = 10;


enum EVENT_TYPE { EV_RECV, EV_SEND, EV_NPC_WANDER };



class Object
{
public:
	int x, y, id;
	bool active;
	std::mutex l_lock;
};

struct OVER_EX
{
	WSAOVERLAPPED overlapped;
	WSABUF wsaBuf;
	EVENT_TYPE event_type;
	char messageBuf[MAX_BUFFER];
};

class NPCINFO : public Object
{
public:
	lua_State *L;
	bool sleeping;
	bool Is_Near_Target(const Object& other) const;
};

class SOCKINFO : public Object
{
public:
	OVER_EX over;
	std::unordered_set<int> client_vl;
	std::unordered_set<int> npc_al;

	int prevBufferSize;
	int socket;
	char packetBuf[MAX_BUFFER];

	SOCKINFO() {
		::memset(&over.overlapped, 0, sizeof(over.overlapped));
		id = -1;
		prevBufferSize = x = y = 0;
		active = false;
		client_vl.clear();
		npc_al.clear();
	}

	bool Is_Near_Object(const Object& other) const;
	bool Is_Awakable_Npc(const NPCINFO& other) const;
};

class ServerManager
{
public:
	std::uniform_int_distribution<> uid;
	std::default_random_engine dre;

	HANDLE g_iocp;
	SOCKINFO clients[MAX_USER];
	NPCINFO npcs[NUM_NPC];

	ServerManager();
	~ServerManager();
	void InitializeServer();
	void error_message(std::string info);
	void lua_errorDisplay(lua_State *L);

	void Accept();
	void do_recv(int id);

	void send_packet(const SOCKINFO& to, void* p);
	void send_login_packet(int to, int res);
	void send_put_player_packet(const SOCKINFO& to, const Object& target);
	void send_move_player_packet(const SOCKINFO& to, const Object& target);
	void send_remove_player_packet(const SOCKINFO& to, const Object& target);
	void disconnect(int id);

	void CSMovePacket_Process(int id, char *packet);

	void InitNpc();
	void LoadPlayer(int id, int _x, int _y);
	std::unordered_set<int> GetNearClientList(int id);
	std::unordered_set<int> GetAwakableNpcList(int id);

	int API_GetClientPosX(lua_State *L);
	int API_GetClientPosY(lua_State *L);
	int API_GetNpcPosX(lua_State *L);
	int API_GetNpcPosY(lua_State *L);
};

